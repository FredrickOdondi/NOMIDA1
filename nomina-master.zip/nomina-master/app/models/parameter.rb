class Parameter < ApplicationRecord
  belongs_to :company
end
