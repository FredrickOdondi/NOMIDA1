require "test_helper"

class PayrollTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
