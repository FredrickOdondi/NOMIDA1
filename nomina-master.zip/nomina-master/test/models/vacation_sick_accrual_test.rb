require "test_helper"

class VacationSickAccrualTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
